Both docker files must access the source code of this repository. Therefore the build context must be the root of the project directory.
Take a look into the build script for the normal py-kms version, as it demonstrates exactly that case and how to use these docker files.
